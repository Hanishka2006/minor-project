import pandas as pd
from sklearn.preprocessing import StandardScaler

# Load your dataset
df = pd.read_csv('sample_songs.csv')

# Normalize relevant features
features = ['danceability', 'energy', 'loudness', 'speechiness', 'acousticness', 
            'instrumentalness', 'liveness', 'valence', 'tempo', 'duration_ms']
scaler = StandardScaler()
df[features] = scaler.fit_transform(df[features])

# Save the preprocessed dataframe
df.to_csv('preprocessed_songs.csv', index=False)

print("Preprocessing complete. Saved to 'preprocessed_songs.csv'.")
