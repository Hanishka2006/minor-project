import pandas as pd
import numpy as np
from sklearn.metrics.pairwise import cosine_similarity

# Load the clustered dataset
df = pd.read_csv('clustered_songs.csv')

# Define features for similarity calculation
features = ['danceability', 'energy', 'loudness', 'speechiness', 'acousticness', 
            'instrumentalness', 'liveness', 'valence', 'tempo', 'duration_ms']

# Compute similarity within clusters
cluster_similarity = {}
for cluster in df['cluster'].unique():
    cluster_data = df[df['cluster'] == cluster]
    similarity = cosine_similarity(cluster_data[features])
    cluster_similarity[cluster] = similarity

# Function to recommend songs
def recommend_songs(song_id, df, cluster_similarity, n_recommendations=5):
    if song_id not in df['track_id'].values:
        return f"Track ID {song_id} not found in the dataset."
    
    cluster = df.loc[df['track_id'] == song_id, 'cluster'].values[0]
    song_index = df[df['track_id'] == song_id].index[0]
    similarity_matrix = cluster_similarity[cluster]
    similar_songs = np.argsort(-similarity_matrix[song_index])[:n_recommendations+1]
    recommendations = df.iloc[similar_songs].iloc[1:]['track_id']
    return recommendations

# Example usage
song_id = '6f807x0ima9a1j3VPbc7VN'  # Replace with an actual track ID from your dataset
recommendations = recommend_songs(song_id, df, cluster_similarity)
print(f"Recommended songs for {song_id}: {recommendations if isinstance(recommendations, str) else recommendations.tolist()}")
